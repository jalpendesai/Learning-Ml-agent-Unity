﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using MLAgents;

public class PyramidAcademy : Academy
{

    public override void AcademyReset()
    {
        
    }

    public override void AcademyStep()
    {

    }
}
